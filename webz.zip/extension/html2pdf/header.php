<?

$content .= '
<table>
<tr>
<td><img src="../../web/imgs/logo.png" alt="logo" style="height: 20px; "></td><td ><font style="font-size:10px;"><i>Cetakan '.$dokumen.' Aplikasi Cashless UniSZA</i></font></td></tr></table>
';

?>
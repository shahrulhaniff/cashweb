<?
$tar = date("d/m/Y - h:i:sa");

//$tar = substr($tar,8,2).'/'.substr($tar,5,2).'/'.substr($tar,0,4);

$content .= '
<table style="width=100%;">
<tr>
<td style="width=100%; " align="right"><font style="font-size:10px;"><i>Dokumen ini dimuaturun melalui sistem Cashless@ Unisza oleh admin pada '.$tar.'</i></font></td></tr></table>
';

?>
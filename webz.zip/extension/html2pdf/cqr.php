<?
$idd = "haha";
include "../qr/qr4html2pdf.php.php";
?>
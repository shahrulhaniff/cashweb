<?php
	define('EMAIL', 'mrtester372@gmail.com');
	define('PASS', 'abcd@1234');
?>
<h1>Prototype: you have done your payment,please close the browser to continue.
<br>

Note: Migs integration cannot be done. we need the access code.
</h1>